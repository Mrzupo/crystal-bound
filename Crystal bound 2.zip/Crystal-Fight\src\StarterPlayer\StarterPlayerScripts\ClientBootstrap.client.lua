--!strict

--[[
	Client Bootstrap

	Entry point for local client startup.
	Use this file later to connect UI, camera, input, and client-only presentation systems.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local localPlayer = Players.LocalPlayer
local Modules = ReplicatedStorage:WaitForChild("Modules")

local sharedModuleNames = {
	"CombatSystem",
	"CrystalSystem",
	"QuestSystem",
	"NPCSystem",
	"InventorySystem",
}

local loadedModules = {}

for _, moduleName in sharedModuleNames do
	local moduleScript = Modules:WaitForChild(moduleName)
	loadedModules[moduleName] = require(moduleScript)
end

for _, module in loadedModules do
	if type(module.Init) == "function" then
		module.Init()
	end
end

for _, module in loadedModules do
	if type(module.Start) == "function" then
		module.Start()
	end
end

-- Keep this reference available for future UI and input setup.
local _player = localPlayer

