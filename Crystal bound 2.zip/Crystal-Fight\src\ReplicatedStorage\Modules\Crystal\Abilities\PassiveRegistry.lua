--!strict

--[[
	PassiveRegistry

	Data-only registry for future passive crystal effects.
	No passive behavior is executed here.
]]

local PassiveRegistry: {
	PassivesByCrystal: { [string]: { string } },
	GetPassives: ((string) -> { string })?,
} = {
	PassivesByCrystal = {
		-- Future shape:
		-- EMBER = {
		-- 	"FuturePassiveId",
		-- },
	},
}

function PassiveRegistry.GetPassives(crystalId: string): { string }
	local passives = PassiveRegistry.PassivesByCrystal[crystalId]
	if type(passives) ~= "table" then
		return {}
	end

	local copy = {}
	for _, passiveId in passives do
		table.insert(copy, passiveId)
	end

	return copy
end

return PassiveRegistry
