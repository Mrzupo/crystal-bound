--!strict

--[[
	BaseCrystal

	Base class for future crystal abilities.
	This class defines a stable API only. It intentionally does not implement
	damage, hitboxes, cooldown enforcement, animation, VFX, mana, energy,
	or status effects.
]]

export type BaseCrystalInstance = {
	CrystalId: string,
	Player: Player?,
	IsInitialized: boolean,
	IsActive: boolean,
	Cooldown: number,
	Initialize: (self: BaseCrystalInstance, player: Player?) -> boolean,
	CanActivate: (self: BaseCrystalInstance) -> boolean,
	Activate: (self: BaseCrystalInstance) -> boolean,
	Deactivate: (self: BaseCrystalInstance) -> boolean,
	GetCooldown: (self: BaseCrystalInstance) -> number,
	Destroy: (self: BaseCrystalInstance) -> (),
}

local BaseCrystal = {}
BaseCrystal.__index = BaseCrystal

function BaseCrystal.new(crystalId: string): BaseCrystalInstance
	local self = setmetatable({
		CrystalId = crystalId,
		Player = nil,
		IsInitialized = false,
		IsActive = false,
		Cooldown = 0,
	}, BaseCrystal)

	return self :: any
end

function BaseCrystal:Initialize(player: Player?): boolean
	self.Player = player
	self.IsInitialized = true
	return true
end

function BaseCrystal:CanActivate(): boolean
	return self.IsInitialized and not self.IsActive
end

function BaseCrystal:Activate(): boolean
	if not self:CanActivate() then
		return false
	end

	self.IsActive = true
	return true
end

function BaseCrystal:Deactivate(): boolean
	if not self.IsActive then
		return false
	end

	self.IsActive = false
	return true
end

function BaseCrystal:GetCooldown(): number
	return self.Cooldown
end

function BaseCrystal:Destroy()
	self.Player = nil
	self.IsInitialized = false
	self.IsActive = false
end

return BaseCrystal

