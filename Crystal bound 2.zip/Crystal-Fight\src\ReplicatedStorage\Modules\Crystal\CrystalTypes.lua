--!strict

--[[
	CrystalTypes

	Central source for crystal rarities and elements.
	Keep these values here so IDs are not duplicated across the project.
]]

local CrystalTypes = {
	Rarities = {
		Common = "Common",
		Rare = "Rare",
		Epic = "Epic",
		Legendary = "Legendary",
		Mythic = "Mythic",
	},

	Elements = {
		Fire = "Fire",
		Water = "Water",
		Wind = "Wind",
	},
}

return CrystalTypes

