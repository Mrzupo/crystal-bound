--!strict

--[[
	QuestService

	Server-side owner for quest progress.
	Later this service should validate quest requirements, rewards,
	progress updates, and completion state.
]]

local QuestService = {}

function QuestService.Init()
	-- Prepare quest definitions and player profile dependencies here later.
end

function QuestService.Start()
	-- Connect quest-related server events and remotes here later.
end

return QuestService

