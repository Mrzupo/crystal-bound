--!strict

--[[
	CombatService

	Server-side authority for combat requests.
	Later this service should validate attacks, cooldowns, targets, damage,
	and anti-exploit checks before updating game state.
]]

local CombatService = {}

function CombatService.Init()
	-- Prepare combat dependencies and remote references here later.
end

function CombatService.Start()
	-- Connect combat remotes and server events here later.
end

return CombatService

