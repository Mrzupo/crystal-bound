--!strict

--[[
	CombatSystem

	Facade for shared combat modules.
	Server-only authority belongs in ServerScriptService services.
]]

local CombatFolder = script.Parent:WaitForChild("Combat")

local CombatSystem = {
	DamageRequest = require(CombatFolder:WaitForChild("DamageRequest")),
	DamageResult = require(CombatFolder:WaitForChild("DamageResult")),
	DamageTypes = require(CombatFolder:WaitForChild("DamageTypes")),
	DamageValidators = require(CombatFolder:WaitForChild("DamageValidators")),
}


return CombatSystem
