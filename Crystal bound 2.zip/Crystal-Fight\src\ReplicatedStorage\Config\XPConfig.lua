--!strict

--[[
	XPConfig

	Shared configuration for experience and progression.
	Avoid placing live player progress here; use PlayerData profiles for that later.
]]

local XPConfig = {
	MaxLevel = 100,
	BaseXP = 100,
	GrowthFactor = 1.18,
}

function XPConfig.GetRequiredXP(level: number): number
	-- Returns the XP needed to advance from the provided level to the next level.
	-- Balance values live in this config module so services do not hard-code them.
	local safeLevel = math.max(1, math.floor(level))
	return math.floor(XPConfig.BaseXP * (XPConfig.GrowthFactor ^ (safeLevel - 1)))
end

return XPConfig
