--!strict

--[[
	InventorySystem

	Shared inventory helpers.
	All item grants, removals, and trades should be validated by server services.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local InventoryConfig = require(ReplicatedStorage:WaitForChild("Config"):WaitForChild("InventoryConfig"))

local InventorySystem = {}

function InventorySystem.Init()
	-- Shared inventory setup can be added here later.
end

function InventorySystem.Start()
	-- Start inventory UI bindings or server observers later.
end

function InventorySystem.GetMaxStackSize(itemId: string): number
	return InventoryConfig.GetMaxStackSize(itemId)
end

function InventorySystem.GetItemType(itemId: string): string?
	local itemConfig = InventoryConfig.GetItemConfig(itemId)
	if not itemConfig then
		return nil
	end

	return itemConfig.Type
end

return InventorySystem
