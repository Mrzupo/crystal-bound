--!strict

--[[
	NPCSystem

	Reserved for NPC definitions, shared NPC metadata, and client/server setup hooks.
	Pathfinding, spawning, and combat authority should be implemented server-side later.
]]

local NPCSystem = {}

function NPCSystem.Init()
	-- Register NPC definitions here later.
end

function NPCSystem.Start()
	-- Start NPC presentation or server orchestration hooks later.
end

return NPCSystem

