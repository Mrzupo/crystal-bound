--!strict

--[[
	EconomyConfig

	Shared economy configuration such as currency names, safe limits,
	price tables, rewards, and shop metadata.
	Server services should validate all spending and rewards.
]]

local EconomyConfig = {
	CurrencyName = "Money",
	StartingMoney = 0,
	MinMoney = 0,
	MaxMoney = 999999999,

	ShopDefaults = {
		AllowPartialPurchases = false,
		RequireServerValidation = true,
	},

	TraderDefaults = {
		AllowSelling = true,
		AllowBuying = true,
	},
}

return EconomyConfig
