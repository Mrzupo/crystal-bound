--!strict

--[[
	CrystalService

	Server-authoritative owner for crystal ownership and equipment.
	This service stores only crystal IDs in PlayerData. Static crystal definitions
	remain in ReplicatedStorage.Modules.Crystal.CrystalDefinitions.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local CrystalModules = Modules:WaitForChild("Crystal")
local Config = ReplicatedStorage:WaitForChild("Config")

local SaveSystem = require(Modules:WaitForChild("SaveSystem"))
local CrystalUtils = require(CrystalModules:WaitForChild("CrystalUtils"))
local AbilityRegistry = require(CrystalModules:WaitForChild("Abilities"):WaitForChild("AbilityRegistry"))
local CrystalConfig = require(Config:WaitForChild("CrystalConfig"))

local CrystalService = {}
local activeAbilities: { [Player]: any } = {}

local function sanitizeCrystalData(crystalData)
	local sanitizedOwned = {}
	local seen = {}

	for _, crystalId in crystalData.Owned do
		if not CrystalUtils.IsValid(crystalId) then
			warn(("[CrystalService] Removing invalid stored crystal id '%s'."):format(tostring(crystalId)))
		elseif seen[crystalId] then
			warn(("[CrystalService] Removing duplicate stored crystal id '%s'."):format(tostring(crystalId)))
		else
			table.insert(sanitizedOwned, crystalId)
			seen[crystalId] = true
		end
	end

	crystalData.Owned = sanitizedOwned

	if crystalData.Equipped ~= "" and not seen[crystalData.Equipped] then
		warn(("[CrystalService] Clearing equipped crystal '%s' because it is not owned or invalid."):format(tostring(crystalData.Equipped)))
		crystalData.Equipped = ""
	end

	return crystalData
end

local function getProfile(player: Player)
	local profile = SaveSystem.GetProfile(player)
	if profile then
		return profile
	end

	return SaveSystem.LoadPlayerAsync(player)
end

local function getCrystalData(player: Player)
	local profile = getProfile(player)
	if not profile then
		return nil
	end

	if type(profile.Crystals) ~= "table" then
		profile.Crystals = {
			Owned = {},
			Equipped = "",
		}
	end

	if type(profile.Crystals.Owned) ~= "table" then
		profile.Crystals.Owned = {}
	end

	if type(profile.Crystals.Equipped) ~= "string" then
		profile.Crystals.Equipped = ""
	end

	return sanitizeCrystalData(profile.Crystals)
end

local function indexOfCrystal(ownedCrystals: { string }, crystalId: string): number?
	for index, ownedCrystalId in ownedCrystals do
		if ownedCrystalId == crystalId then
			return index
		end
	end

	return nil
end

function CrystalService.Init()
	if not CrystalUtils.IsValid(CrystalConfig.DefaultCrystal) then
		error(("[CrystalService] DefaultCrystal '%s' is not a valid crystal id."):format(tostring(CrystalConfig.DefaultCrystal)))
	end
end

function CrystalService.Start()
	-- No remotes are connected for Crystal Framework v1.
	-- Future gameplay systems should call this service from server code only.
	Players.PlayerRemoving:Connect(function(player)
		local activeAbility = activeAbilities[player]
		if activeAbility then
			activeAbility:Destroy()
			activeAbilities[player] = nil
		end
	end)
end

--[[
	GetOwnedCrystals(player) -> { string }?

	Returns a copy of the player's unlocked crystal IDs.
	Returns nil if the player's profile is unavailable.
]]
function CrystalService.GetOwnedCrystals(player: Player): { string }?
	local crystalData = getCrystalData(player)
	if not crystalData then
		warn(("[CrystalService] Cannot read crystals for %s because no profile is available."):format(player.Name))
		return nil
	end

	local ownedCopy = {}
	for _, crystalId in crystalData.Owned do
		table.insert(ownedCopy, crystalId)
	end

	return ownedCopy
end

--[[
	OwnsCrystal(player, crystalId) -> boolean

	Returns true when the player has unlocked crystalId.
	Invalid crystal IDs are rejected.
]]
function CrystalService.OwnsCrystal(player: Player, crystalId: string): boolean
	if not CrystalUtils.IsValid(crystalId) then
		warn(("[CrystalService] OwnsCrystal rejected invalid crystal id '%s'."):format(tostring(crystalId)))
		return false
	end

	local crystalData = getCrystalData(player)
	if not crystalData then
		warn(("[CrystalService] Cannot check crystal ownership for %s because no profile is available."):format(player.Name))
		return false
	end

	return indexOfCrystal(crystalData.Owned, crystalId) ~= nil
end

--[[
	UnlockCrystal(player, crystalId) -> boolean

	Unlocks crystalId for the player if it is valid and not already owned.
	Returns false for invalid IDs, duplicates, missing profiles, or ownership cap.
]]
function CrystalService.UnlockCrystal(player: Player, crystalId: string): boolean
	if not CrystalUtils.IsValid(crystalId) then
		warn(("[CrystalService] UnlockCrystal rejected invalid crystal id '%s'."):format(tostring(crystalId)))
		return false
	end

	local crystalData = getCrystalData(player)
	if not crystalData then
		warn(("[CrystalService] Cannot unlock crystal for %s because no profile is available."):format(player.Name))
		return false
	end

	if indexOfCrystal(crystalData.Owned, crystalId) then
		warn(("[CrystalService] %s already owns crystal '%s'."):format(player.Name, crystalId))
		return false
	end

	if #crystalData.Owned >= CrystalConfig.MaxOwnedCrystals then
		warn(("[CrystalService] %s cannot unlock '%s'; max owned crystals reached."):format(player.Name, crystalId))
		return false
	end

	table.insert(crystalData.Owned, crystalId)
	return true
end

--[[
	EquipCrystal(player, crystalId) -> boolean

	Equips one owned crystal. Only one crystal can be equipped at a time.
	Returns false when the crystal is invalid, not owned, or the profile is unavailable.
]]
function CrystalService.EquipCrystal(player: Player, crystalId: string): boolean
	if not CrystalUtils.IsValid(crystalId) then
		warn(("[CrystalService] EquipCrystal rejected invalid crystal id '%s'."):format(tostring(crystalId)))
		return false
	end

	local crystalData = getCrystalData(player)
	if not crystalData then
		warn(("[CrystalService] Cannot equip crystal for %s because no profile is available."):format(player.Name))
		return false
	end

	if not indexOfCrystal(crystalData.Owned, crystalId) then
		warn(("[CrystalService] %s cannot equip unowned crystal '%s'."):format(player.Name, crystalId))
		return false
	end

	crystalData.Equipped = crystalId

	if activeAbilities[player] then
		activeAbilities[player]:Destroy()
		activeAbilities[player] = nil
	end

	return true
end

--[[
	GetEquippedCrystal(player) -> string?

	Returns the equipped crystal ID, or an empty string when none is equipped.
	Returns nil if the player's profile is unavailable.
]]
function CrystalService.GetEquippedCrystal(player: Player): string?
	local crystalData = getCrystalData(player)
	if not crystalData then
		warn(("[CrystalService] Cannot read equipped crystal for %s because no profile is available."):format(player.Name))
		return nil
	end

	return crystalData.Equipped
end

--[[
	GetActiveAbility(player) -> any?

	Returns the current placeholder ability instance for the equipped crystal.
	If no instance exists yet, it creates a BaseCrystal-backed ability through
	AbilityRegistry. No gameplay behavior is executed here.
]]
function CrystalService.GetActiveAbility(player: Player)
	local equippedCrystal = CrystalService.GetEquippedCrystal(player)
	if not equippedCrystal or equippedCrystal == "" then
		return nil
	end

	local activeAbility = activeAbilities[player]
	if activeAbility and activeAbility.CrystalId == equippedCrystal then
		return activeAbility
	end

	if activeAbility then
		activeAbility:Destroy()
	end

	activeAbility = AbilityRegistry.CreateAbility(equippedCrystal)
	activeAbility:Initialize(player)
	activeAbilities[player] = activeAbility

	return activeAbility
end

--[[
	CanUseAbility(player) -> boolean

	Placeholder check for future ability activation.
	Currently delegates only to BaseCrystal.CanActivate.
]]
function CrystalService.CanUseAbility(player: Player): boolean
	local activeAbility = CrystalService.GetActiveAbility(player)
	if not activeAbility then
		return false
	end

	return activeAbility:CanActivate()
end

--[[
	ActivateAbility(player) -> boolean

	Placeholder activation hook for the equipped crystal ability.
	This does not apply damage, effects, cooldowns, resources, hitboxes, VFX,
	or animations.
]]
function CrystalService.ActivateAbility(player: Player): boolean
	local activeAbility = CrystalService.GetActiveAbility(player)
	if not activeAbility then
		return false
	end

	return activeAbility:Activate()
end

--[[
	DeactivateAbility(player) -> boolean

	Placeholder deactivation hook for the equipped crystal ability.
]]
function CrystalService.DeactivateAbility(player: Player): boolean
	local activeAbility = activeAbilities[player]
	if not activeAbility then
		return false
	end

	return activeAbility:Deactivate()
end

return CrystalService
