--!strict

--[[
	DamageResult

	Shared result model for the damage pipeline.
	WasCritical and WasBlocked are placeholders for future combat systems.
]]

export type DamageResult = {
	Success: boolean,
	FinalDamage: number,
	Reason: string,
	WasCritical: boolean,
	WasBlocked: boolean,
}

local DamageResult = {}

function DamageResult.success(finalDamage: number, reason: string?): DamageResult
	return {
		Success = true,
		FinalDamage = finalDamage,
		Reason = reason or "OK",
		WasCritical = false,
		WasBlocked = false,
	}
end

function DamageResult.failure(reason: string): DamageResult
	return {
		Success = false,
		FinalDamage = 0,
		Reason = reason,
		WasCritical = false,
		WasBlocked = false,
	}
end

return DamageResult

