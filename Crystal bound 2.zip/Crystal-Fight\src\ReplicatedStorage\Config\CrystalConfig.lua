--!strict

--[[
	CrystalConfig

	Configuration for the crystal framework.
	This file contains only configuration values, not gameplay logic.
]]

local CrystalConfig = {
	DefaultCrystal = "EMBER",
	MaxOwnedCrystals = 50,
	AllowCrystalSwitchInCombat = false,
}

return CrystalConfig
