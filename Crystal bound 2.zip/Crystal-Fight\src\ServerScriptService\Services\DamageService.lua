--!strict

--[[
	DamageService

	Server-side entry point for the future damage pipeline.
	Current scope: validate and prepare damage results only.

	This service explicitly does not damage Humanoids, run hitboxes, apply
	armor, calculate critical hits, block, dodge, or status effects.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local CombatModules = ReplicatedStorage:WaitForChild("Modules"):WaitForChild("Combat")

local DamageResult = require(CombatModules:WaitForChild("DamageResult"))
local DamageValidators = require(CombatModules:WaitForChild("DamageValidators"))

local DamageService = {}

function DamageService.Init()
	-- Reserved for future service dependencies.
end

function DamageService.Start()
	-- No remotes or listeners are connected in this framework stage.
end

--[[
	ValidateRequest(request) -> DamageResult

	Validates request shape, attacker, target, positive damage, and damage type.
]]
function DamageService.ValidateRequest(request: any)
	local isValid, reason = DamageValidators.ValidateRequest(request)
	if not isValid then
		return DamageResult.failure(reason)
	end

	return DamageResult.success(request.Damage, "VALID")
end

--[[
	CanDamage(request) -> boolean

	Boolean convenience wrapper around ValidateRequest.
]]
function DamageService.CanDamage(request: any): boolean
	return DamageService.ValidateRequest(request).Success
end

--[[
	ProcessDamage(request) -> DamageResult

	Runs validation and returns a prepared result.
	No formulas or modifiers are applied yet.
]]
function DamageService.ProcessDamage(request: any)
	local validationResult = DamageService.ValidateRequest(request)
	if not validationResult.Success then
		return validationResult
	end

	return DamageResult.success(request.Damage, "PREPARED")
end

--[[
	ApplyDamage(request) -> DamageResult

	Framework placeholder for future final application.
	Currently validates and prepares only. It does not modify Humanoids or state.
]]
function DamageService.ApplyDamage(request: any)
	local processedResult = DamageService.ProcessDamage(request)
	if not processedResult.Success then
		return processedResult
	end

	return DamageResult.success(processedResult.FinalDamage, "NOT_APPLIED_FRAMEWORK_ONLY")
end

return DamageService

