--!strict

--[[
	QuestSystem

	Reserved for quest definitions and shared quest helper functions.
	Server-side quest progress should be validated in a dedicated service.
]]

local QuestSystem = {}

function QuestSystem.Init()
	-- Add quest definitions and dependency checks here later.
end

function QuestSystem.Start()
	-- Start quest-related observers here later.
end

return QuestSystem

