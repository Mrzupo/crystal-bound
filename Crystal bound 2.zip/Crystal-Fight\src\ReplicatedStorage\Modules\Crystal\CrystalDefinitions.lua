--!strict

--[[
	CrystalDefinitions

	Static crystal catalog for Crystal Fight.
	Only definition data belongs here. Player ownership and equipped state are
	stored in PlayerData as crystal IDs.
]]

local CrystalTypes = require(script.Parent:WaitForChild("CrystalTypes"))

export type CrystalDefinition = {
	Id: string,
	DisplayName: string,
	Description: string,
	Rarity: string,
	Element: string,
	UnlockLevel: number,
}

local CrystalDefinitions: { [string]: CrystalDefinition } = {
	EMBER = {
		Id = "EMBER",
		DisplayName = "Ember",
		Description = "A volatile starter crystal carrying a controlled fire aspect.",
		Rarity = CrystalTypes.Rarities.Common,
		Element = CrystalTypes.Elements.Fire,
		UnlockLevel = 1,
	},

	TIDE = {
		Id = "TIDE",
		DisplayName = "Tide",
		Description = "A balanced water crystal intended for future defensive paths.",
		Rarity = CrystalTypes.Rarities.Rare,
		Element = CrystalTypes.Elements.Water,
		UnlockLevel = 3,
	},

	GALE = {
		Id = "GALE",
		DisplayName = "Gale",
		Description = "A wind crystal prepared for future mobility-focused systems.",
		Rarity = CrystalTypes.Rarities.Epic,
		Element = CrystalTypes.Elements.Wind,
		UnlockLevel = 5,
	},
}

return CrystalDefinitions

