--!strict

--[[
	SaveSystem

	Server-side persistence owner for Crystal Fight player profiles.
	This module creates profiles on join, loads saved data, autosaves active profiles,
	and saves one final time when players leave or the server shuts down.
]]

local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local PlayerData = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("PlayerData"))

local DATASTORE_NAME = "CrystalFight_PlayerProfiles_v1"
local AUTOSAVE_INTERVAL = 60
local MAX_RETRIES = 3
local RETRY_DELAY = 2

local SaveSystem = {}

local profileStore = DataStoreService:GetDataStore(DATASTORE_NAME)
local profiles: { [Player]: PlayerData.Profile } = {}
local loadedSafely: { [Player]: boolean } = {}
local savingPlayers: { [Player]: boolean } = {}
local started = false
local shuttingDown = false

local function getKey(player: Player): string
	return "Player_" .. player.UserId
end

local function deepCopy(value: any): any
	if type(value) ~= "table" then
		return value
	end

	local copy = {}
	for key, child in value do
		copy[key] = deepCopy(child)
	end

	return copy
end

local function reconcileWithDefaults(savedProfile: any): PlayerData.Profile
	local defaultProfile = PlayerData.GetDefaultProfile()

	if type(savedProfile) ~= "table" then
		return defaultProfile
	end

	local function reconcile(defaultValue: any, savedValue: any): any
		if type(defaultValue) ~= "table" then
			if savedValue ~= nil and type(savedValue) == type(defaultValue) then
				return savedValue
			end

			return defaultValue
		end

		if type(savedValue) ~= "table" then
			return deepCopy(defaultValue)
		end

		local result = deepCopy(defaultValue)

		for key, value in savedValue do
			local defaultChild = defaultValue[key]
			if defaultChild ~= nil then
				result[key] = reconcile(defaultChild, value)
			else
				-- Preserve existing fields so future migrations do not silently erase data.
				result[key] = deepCopy(value)
			end
		end

		return result
	end

	return reconcile(defaultProfile, savedProfile)
end

local function datastoreRequest(callback: () -> any): (boolean, any)
	local lastError = nil

	for attempt = 1, MAX_RETRIES do
		local success, result = pcall(callback)
		if success then
			return true, result
		end

		lastError = result
		warn(("[SaveSystem] DataStore request failed. Attempt %d/%d: %s"):format(attempt, MAX_RETRIES, tostring(result)))

		if attempt < MAX_RETRIES then
			task.wait(RETRY_DELAY * attempt)
		end
	end

	return false, lastError
end

function SaveSystem.Init()
	if not RunService:IsServer() then
		error("SaveSystem can only run on the server.")
	end
end

function SaveSystem.Start()
	if started then
		return
	end

	started = true

	Players.PlayerAdded:Connect(function(player)
		SaveSystem.LoadPlayerAsync(player)
	end)

	Players.PlayerRemoving:Connect(function(player)
		SaveSystem.SavePlayerAsync(player)
		profiles[player] = nil
		loadedSafely[player] = nil
		savingPlayers[player] = nil
	end)

	task.spawn(function()
		while not shuttingDown do
			task.wait(AUTOSAVE_INTERVAL)

			for player in profiles do
				task.spawn(function()
					SaveSystem.SavePlayerAsync(player)
				end)
			end
		end
	end)

	game:BindToClose(function()
		shuttingDown = true

		for player in profiles do
			SaveSystem.SavePlayerAsync(player)
		end
	end)

	for _, player in Players:GetPlayers() do
		task.spawn(function()
			SaveSystem.LoadPlayerAsync(player)
		end)
	end
end

function SaveSystem.LoadPlayerAsync(player: Player): PlayerData.Profile?
	if profiles[player] then
		return profiles[player]
	end

	local key = getKey(player)
	local success, savedProfile = datastoreRequest(function()
		return profileStore:GetAsync(key)
	end)

	local profile: PlayerData.Profile

	if success and savedProfile ~= nil then
		profile = reconcileWithDefaults(savedProfile)
		loadedSafely[player] = true
	elseif success then
		profile = PlayerData.GetDefaultProfile()
		loadedSafely[player] = true
	else
		-- Give the player a safe in-memory profile so the session can continue.
		-- Because loading failed, normal saving is blocked to avoid overwriting real data
		-- with a default profile after a temporary DataStore outage.
		warn(("[SaveSystem] Using default in-memory profile for %s after load failure."):format(player.Name))
		profile = PlayerData.GetDefaultProfile()
		loadedSafely[player] = false
	end

	if not PlayerData.ValidateProfile(profile) then
		warn(("[SaveSystem] Invalid profile for %s. Falling back to default profile."):format(player.Name))
		profile = PlayerData.GetDefaultProfile()
	end

	profile.Inventory = PlayerData.NormalizeInventory(profile.Inventory)

	profiles[player] = profile
	return profile
end

function SaveSystem.SavePlayerAsync(player: Player, profileOverride: PlayerData.Profile?): boolean
	if savingPlayers[player] then
		local waitStartedAt = os.clock()

		while savingPlayers[player] and os.clock() - waitStartedAt < 10 do
			task.wait(0.1)
		end

		if savingPlayers[player] then
			warn(("[SaveSystem] Timed out waiting for existing save for %s."):format(player.Name))
			return false
		end
	end

	local profile = profileOverride or profiles[player]
	if not profile then
		return false
	end

	if loadedSafely[player] == false and profileOverride == nil then
		warn(("[SaveSystem] Refusing to save %s because their profile did not load safely."):format(player.Name))
		return false
	end

	if not PlayerData.ValidateProfile(profile) then
		warn(("[SaveSystem] Refusing to save invalid profile for %s."):format(player.Name))
		return false
	end

	savingPlayers[player] = true

	local key = getKey(player)
	local profileToSave = deepCopy(profile)
	local success = datastoreRequest(function()
		return profileStore:UpdateAsync(key, function()
			return profileToSave
		end)
	end)

	savingPlayers[player] = nil

	if not success then
		warn(("[SaveSystem] Failed to save profile for %s."):format(player.Name))
	end

	return success
end

function SaveSystem.GetProfile(player: Player): PlayerData.Profile?
	return profiles[player]
end

function SaveSystem.GetProfiles(): { [Player]: PlayerData.Profile }
	return profiles
end

return SaveSystem
