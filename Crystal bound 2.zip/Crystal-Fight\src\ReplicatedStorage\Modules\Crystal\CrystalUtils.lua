--!strict

--[[
	CrystalUtils

	Read-only helpers for crystal definitions.
	These functions must never mutate PlayerData or server state.
]]

local CrystalDefinitions = require(script.Parent:WaitForChild("CrystalDefinitions"))

local CrystalUtils = {}

function CrystalUtils.Exists(id: string): boolean
	return type(id) == "string" and CrystalDefinitions[id] ~= nil
end

function CrystalUtils.GetDefinition(id: string)
	if not CrystalUtils.Exists(id) then
		return nil
	end

	return CrystalDefinitions[id]
end

function CrystalUtils.IsValid(id: string): boolean
	local definition = CrystalUtils.GetDefinition(id)
	if not definition then
		return false
	end

	return definition.Id == id
		and type(definition.DisplayName) == "string"
		and type(definition.Description) == "string"
		and type(definition.Rarity) == "string"
		and type(definition.Element) == "string"
		and type(definition.UnlockLevel) == "number"
end

return CrystalUtils

