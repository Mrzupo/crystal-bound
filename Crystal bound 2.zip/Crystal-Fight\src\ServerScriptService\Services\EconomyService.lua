--!strict

--[[
	EconomyService

	Server-side owner for player money.
	All future shops, traders, rewards, and purchases should use this service
	instead of editing profile.Money directly.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Config = ReplicatedStorage:WaitForChild("Config")
local Remotes = ReplicatedStorage:WaitForChild("Remotes")

local SaveSystem = require(Modules:WaitForChild("SaveSystem"))
local EconomyConfig = require(Config:WaitForChild("EconomyConfig"))

local EconomyService = {}

local moneyChangedRemote: RemoteEvent

local function getProfile(player: Player)
	local profile = SaveSystem.GetProfile(player)
	if profile then
		return profile
	end

	return SaveSystem.LoadPlayerAsync(player)
end

local function normalizeAmount(amount: number): number?
	if amount ~= amount or amount == math.huge or amount == -math.huge then
		return nil
	end

	local normalized = math.floor(amount)
	if normalized <= 0 then
		return nil
	end

	return normalized
end

local function clampMoney(value: number): number
	return math.clamp(value, EconomyConfig.MinMoney, EconomyConfig.MaxMoney)
end

local function fireMoneyChanged(player: Player, money: number, delta: number)
	moneyChangedRemote:FireClient(player, {
		Money = money,
		Delta = delta,
		CurrencyName = EconomyConfig.CurrencyName,
	})
end

function EconomyService.Init()
	moneyChangedRemote = Remotes:WaitForChild("MoneyChanged") :: RemoteEvent
end

function EconomyService.Start()
	-- No startup work is required yet. Future shop and trader systems should
	-- call this service directly for all money changes.
end

--[[
	AddMoney(player, amount) -> boolean

	Adds positive money to the player's loaded profile.
	Returns true when money was added, false when the player/profile/amount is invalid.
	Money is clamped to EconomyConfig.MaxMoney.
]]
function EconomyService.AddMoney(player: Player, amount: number): boolean
	local normalizedAmount = normalizeAmount(amount)
	if not normalizedAmount then
		return false
	end

	local profile = getProfile(player)
	if not profile then
		warn(("[EconomyService] Could not add money for %s because no profile is available."):format(player.Name))
		return false
	end

	local oldMoney = clampMoney(profile.Money)
	profile.Money = oldMoney

	local newMoney = clampMoney(oldMoney + normalizedAmount)
	local delta = newMoney - oldMoney

	if delta <= 0 then
		return false
	end

	profile.Money = newMoney
	fireMoneyChanged(player, newMoney, delta)
	return true
end

--[[
	RemoveMoney(player, amount) -> boolean

	Removes positive money from the player's loaded profile.
	Returns true when the full amount was removed.
	Returns false if the player cannot afford the amount.
	Money is never allowed to become negative.
]]
function EconomyService.RemoveMoney(player: Player, amount: number): boolean
	local normalizedAmount = normalizeAmount(amount)
	if not normalizedAmount then
		return false
	end

	local profile = getProfile(player)
	if not profile then
		warn(("[EconomyService] Could not remove money for %s because no profile is available."):format(player.Name))
		return false
	end

	local oldMoney = clampMoney(profile.Money)
	profile.Money = oldMoney

	if oldMoney < normalizedAmount then
		return false
	end

	local newMoney = clampMoney(oldMoney - normalizedAmount)
	profile.Money = newMoney
	fireMoneyChanged(player, newMoney, newMoney - oldMoney)
	return true
end

--[[
	GetMoney(player) -> number?

	Returns the player's current money from the loaded profile.
	Returns nil when no profile is available.
]]
function EconomyService.GetMoney(player: Player): number?
	local profile = getProfile(player)
	if not profile then
		return nil
	end

	profile.Money = clampMoney(profile.Money)
	return profile.Money
end

--[[
	CanAfford(player, amount) -> boolean

	Returns true when the player's current money is greater than or equal to amount.
	This does not modify the profile and should be used before purchases or trades.
]]
function EconomyService.CanAfford(player: Player, amount: number): boolean
	local normalizedAmount = normalizeAmount(amount)
	if not normalizedAmount then
		return false
	end

	local money = EconomyService.GetMoney(player)
	if money == nil then
		return false
	end

	return money >= normalizedAmount
end

return EconomyService
