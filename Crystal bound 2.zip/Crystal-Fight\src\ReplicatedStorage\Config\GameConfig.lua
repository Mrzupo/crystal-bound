--!strict

--[[
	GameConfig

	Reserved for high-level game settings that should be shared by server and client.
	Keep values here descriptive and stable. Runtime state should live in services.
]]

local GameConfig = {
	-- Add global configuration values here later.
}

return GameConfig

