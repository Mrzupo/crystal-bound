--!strict

--[[
	EnemyConfig

	Reserved for enemy definitions and shared enemy metadata.
	Spawning, combat decisions, and reward granting should remain server-authoritative.
]]

local EnemyConfig = {
	-- Add enemy definitions here later.
}

return EnemyConfig

