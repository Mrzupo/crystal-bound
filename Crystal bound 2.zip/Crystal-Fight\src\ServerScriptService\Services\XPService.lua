--!strict

--[[
	XPService

	Server-side owner for player XP and level progression.
	Other server systems should award progression through AddXP(player, amount).
	This service updates the existing PlayerData profile and notifies future UI
	through RemoteEvents. It does not create any UI.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Config = ReplicatedStorage:WaitForChild("Config")
local Remotes = ReplicatedStorage:WaitForChild("Remotes")

local SaveSystem = require(Modules:WaitForChild("SaveSystem"))
local XPConfig = require(Config:WaitForChild("XPConfig"))

local XPService = {}

local xpChangedRemote: RemoteEvent
local levelUpRemote: RemoteEvent

local function getProfile(player: Player)
	local profile = SaveSystem.GetProfile(player)
	if profile then
		return profile
	end

	-- This fallback keeps the service usable if another server system awards XP
	-- immediately after PlayerAdded but before SaveSystem finishes loading.
	return SaveSystem.LoadPlayerAsync(player)
end

local function getRequiredXP(level: number): number
	return XPConfig.GetRequiredXP(level)
end

local function fireXPChanged(player: Player, level: number, experience: number, requiredXP: number)
	xpChangedRemote:FireClient(player, {
		Level = level,
		Experience = experience,
		RequiredXP = requiredXP,
	})
end

function XPService.Init()
	xpChangedRemote = Remotes:WaitForChild("XPChanged") :: RemoteEvent
	levelUpRemote = Remotes:WaitForChild("LevelUp") :: RemoteEvent
end

function XPService.Start()
	-- No connections are needed yet. Future gameplay systems can require this
	-- service and call AddXP when enemies, quests, or other rewards exist.
end

function XPService.AddXP(player: Player, amount: number): boolean
	if amount <= 0 then
		return false
	end

	local profile = getProfile(player)
	if not profile then
		warn(("[XPService] Could not add XP for %s because no profile is available."):format(player.Name))
		return false
	end

	local xpToAdd = math.floor(amount)
	if xpToAdd <= 0 then
		return false
	end

	profile.Experience += xpToAdd

	local oldLevel = profile.Level
	local maxLevel = XPConfig.MaxLevel

	while profile.Level < maxLevel do
		local requiredXP = getRequiredXP(profile.Level)
		if profile.Experience < requiredXP then
			break
		end

		profile.Experience -= requiredXP
		profile.Level += 1
	end

	if profile.Level >= maxLevel then
		profile.Level = maxLevel
		profile.Experience = math.max(0, profile.Experience)
	end

	if profile.Level > oldLevel then
		levelUpRemote:FireClient(player, {
			OldLevel = oldLevel,
			NewLevel = profile.Level,
			LevelsGained = profile.Level - oldLevel,
		})
	end

	fireXPChanged(player, profile.Level, profile.Experience, getRequiredXP(profile.Level))
	return true
end

function XPService.GetLevel(player: Player): number?
	local profile = getProfile(player)
	if not profile then
		return nil
	end

	return profile.Level
end

function XPService.GetXP(player: Player): number?
	local profile = getProfile(player)
	if not profile then
		return nil
	end

	return profile.Experience
end

return XPService

