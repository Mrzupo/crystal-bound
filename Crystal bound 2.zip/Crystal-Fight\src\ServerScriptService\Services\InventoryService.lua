--!strict

--[[
	InventoryService

	Server-side owner for player inventories.
	All future drops, shops, traders, crystals, materials, and quest rewards
	should modify inventory through this service.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Config = ReplicatedStorage:WaitForChild("Config")
local Remotes = ReplicatedStorage:WaitForChild("Remotes")

local SaveSystem = require(Modules:WaitForChild("SaveSystem"))
local PlayerData = require(Modules:WaitForChild("PlayerData"))
local InventoryConfig = require(Config:WaitForChild("InventoryConfig"))

local InventoryService = {}

local inventoryChangedRemote: RemoteEvent

local function getProfile(player: Player)
	local profile = SaveSystem.GetProfile(player)
	if profile then
		profile.Inventory = PlayerData.NormalizeInventory(profile.Inventory)
		return profile
	end

	profile = SaveSystem.LoadPlayerAsync(player)
	if profile then
		profile.Inventory = PlayerData.NormalizeInventory(profile.Inventory)
	end

	return profile
end

local function normalizeAmount(amount: number): number?
	if amount ~= amount or amount == math.huge or amount == -math.huge then
		return nil
	end

	local normalized = math.floor(amount)
	if normalized <= 0 then
		return nil
	end

	return normalized
end

local function isValidItemId(itemId: string): boolean
	return type(itemId) == "string" and itemId ~= ""
end

local function fireInventoryChanged(player: Player, itemId: string, amount: number, delta: number, inventory: { [string]: number })
	inventoryChangedRemote:FireClient(player, {
		ItemId = itemId,
		Amount = amount,
		Delta = delta,
		Inventory = inventory,
	})
end

local function copyInventory(inventory: { [string]: number }): { [string]: number }
	local copy = {}
	for itemId, amount in inventory do
		copy[itemId] = amount
	end

	return copy
end

function InventoryService.Init()
	inventoryChangedRemote = Remotes:WaitForChild("InventoryChanged") :: RemoteEvent
end

function InventoryService.Start()
	-- No startup work is required yet. Future gameplay systems should call
	-- this service directly when granting or removing items.
end

--[[
	AddItem(player, itemId, amount) -> boolean

	Adds a positive amount of itemId to the player's inventory.
	Returns true when the item was added.
	Returns false when the profile, itemId, amount, or stack limit is invalid.
	Max stack size comes from InventoryConfig.
]]
function InventoryService.AddItem(player: Player, itemId: string, amount: number): boolean
	if not isValidItemId(itemId) then
		return false
	end

	local normalizedAmount = normalizeAmount(amount)
	if not normalizedAmount then
		return false
	end

	local profile = getProfile(player)
	if not profile then
		warn(("[InventoryService] Could not add %s for %s because no profile is available."):format(itemId, player.Name))
		return false
	end

	local maxStackSize = InventoryConfig.GetMaxStackSize(itemId)
	local currentAmount = profile.Inventory[itemId] or 0
	if currentAmount >= maxStackSize then
		return false
	end

	local newAmount = math.min(currentAmount + normalizedAmount, maxStackSize)
	local delta = newAmount - currentAmount
	if delta <= 0 then
		return false
	end

	profile.Inventory[itemId] = newAmount
	fireInventoryChanged(player, itemId, newAmount, delta, copyInventory(profile.Inventory))
	return true
end

--[[
	RemoveItem(player, itemId, amount) -> boolean

	Removes a positive amount of itemId from the player's inventory.
	Returns true only when the full amount was removed.
	Returns false if the player does not have enough of the item.
]]
function InventoryService.RemoveItem(player: Player, itemId: string, amount: number): boolean
	if not isValidItemId(itemId) then
		return false
	end

	local normalizedAmount = normalizeAmount(amount)
	if not normalizedAmount then
		return false
	end

	local profile = getProfile(player)
	if not profile then
		warn(("[InventoryService] Could not remove %s for %s because no profile is available."):format(itemId, player.Name))
		return false
	end

	local currentAmount = profile.Inventory[itemId] or 0
	if currentAmount < normalizedAmount then
		return false
	end

	local newAmount = currentAmount - normalizedAmount
	if newAmount > 0 then
		profile.Inventory[itemId] = newAmount
	else
		profile.Inventory[itemId] = nil
	end

	fireInventoryChanged(player, itemId, newAmount, -normalizedAmount, copyInventory(profile.Inventory))
	return true
end

--[[
	HasItem(player, itemId) -> boolean

	Returns true when the player has at least one of itemId.
	This does not modify the profile.
]]
function InventoryService.HasItem(player: Player, itemId: string): boolean
	if not isValidItemId(itemId) then
		return false
	end

	local profile = getProfile(player)
	if not profile then
		return false
	end

	return (profile.Inventory[itemId] or 0) > 0
end

--[[
	GetInventory(player) -> { [string]: number }?

	Returns a copy of the player's inventory map.
	Returns nil when no profile is available.
	The returned table is a copy so callers cannot mutate profile data directly.
]]
function InventoryService.GetInventory(player: Player): { [string]: number }?
	local profile = getProfile(player)
	if not profile then
		return nil
	end

	return copyInventory(profile.Inventory)
end

return InventoryService

