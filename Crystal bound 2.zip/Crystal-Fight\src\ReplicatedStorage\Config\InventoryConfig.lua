--!strict

--[[
	InventoryConfig

	Shared inventory configuration for stack sizes and item metadata.
	Server services remain authoritative for grants, removals, trades, and rewards.
]]

export type ItemConfig = {
	DisplayName: string?,
	Type: string?,
	MaxStackSize: number?,
	Tradable: boolean?,
	QuestBound: boolean?,
}

local InventoryConfig = {
	DefaultMaxStackSize = 99,

	ItemTypes = {
		Crystal = "Crystal",
		Material = "Material",
		QuestItem = "QuestItem",
		Consumable = "Consumable",
	},

	Items = {} :: { [string]: ItemConfig },
		-- Example shape for future entries:
		-- CrystalShard = {
		-- 	DisplayName = "Crystal Shard",
		-- 	Type = "Material",
		-- 	MaxStackSize = 999,
		-- 	Tradable = true,
		-- 	QuestBound = false,
		-- },
}

function InventoryConfig.GetItemConfig(itemId: string): ItemConfig?
	return InventoryConfig.Items[itemId]
end

function InventoryConfig.GetMaxStackSize(itemId: string): number
	local itemConfig = InventoryConfig.GetItemConfig(itemId)
	if itemConfig and type(itemConfig.MaxStackSize) == "number" then
		return math.max(1, math.floor(itemConfig.MaxStackSize))
	end

	return InventoryConfig.DefaultMaxStackSize
end

return InventoryConfig
