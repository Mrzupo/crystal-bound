--!strict

--[[
	DamageValidators

	Validation-only helpers for damage requests.
	No damage calculation or application belongs here.
]]

local DamageTypes = require(script.Parent:WaitForChild("DamageTypes"))

local DamageValidators = {}

local validDamageTypes = {}
for _, damageType in DamageTypes do
	validDamageTypes[damageType] = true
end

function DamageValidators.IsValidAttacker(attacker: any): (boolean, string)
	if attacker == nil then
		return false, "INVALID_ATTACKER"
	end

	return true, "OK"
end

function DamageValidators.IsValidTarget(target: any): (boolean, string)
	if target == nil then
		return false, "INVALID_TARGET"
	end

	return true, "OK"
end

function DamageValidators.IsPositiveDamage(damage: any): (boolean, string)
	if type(damage) ~= "number" then
		return false, "INVALID_DAMAGE"
	end

	if damage ~= damage or damage == math.huge or damage == -math.huge then
		return false, "INVALID_DAMAGE"
	end

	if damage <= 0 then
		return false, "DAMAGE_NOT_POSITIVE"
	end

	return true, "OK"
end

function DamageValidators.IsValidDamageType(damageType: any): (boolean, string)
	if type(damageType) ~= "string" then
		return false, "INVALID_DAMAGE_TYPE"
	end

	if not validDamageTypes[damageType] then
		return false, "UNKNOWN_DAMAGE_TYPE"
	end

	return true, "OK"
end

function DamageValidators.ValidateRequest(request: any): (boolean, string)
	if type(request) ~= "table" then
		return false, "INVALID_REQUEST"
	end

	local attackerValid, attackerReason = DamageValidators.IsValidAttacker(request.Attacker)
	if not attackerValid then
		return false, attackerReason
	end

	local targetValid, targetReason = DamageValidators.IsValidTarget(request.Target)
	if not targetValid then
		return false, targetReason
	end

	local damageValid, damageReason = DamageValidators.IsPositiveDamage(request.Damage)
	if not damageValid then
		return false, damageReason
	end

	local typeValid, typeReason = DamageValidators.IsValidDamageType(request.DamageType)
	if not typeValid then
		return false, typeReason
	end

	return true, "OK"
end

return DamageValidators

