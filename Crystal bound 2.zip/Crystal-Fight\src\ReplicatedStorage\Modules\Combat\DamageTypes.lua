--!strict

--[[
	DamageTypes

	Central constants for damage categories.
	This module contains no logic.
]]

local DamageTypes = {
	Physical = "Physical",
	Crystal = "Crystal",
	True = "True",
	Environmental = "Environmental",
}

return DamageTypes

