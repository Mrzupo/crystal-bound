--!strict

--[[
	PlayerService

	Server-side owner for player lifecycle orchestration.
	Later this service can connect player joins, player leaves, profile setup,
	and safe access to PlayerData without exposing authority to the client.
]]

local PlayerService = {}

function PlayerService.Init()
	-- Prepare player-related dependencies here later.
end

function PlayerService.Start()
	-- Connect player lifecycle events here later.
end

return PlayerService

