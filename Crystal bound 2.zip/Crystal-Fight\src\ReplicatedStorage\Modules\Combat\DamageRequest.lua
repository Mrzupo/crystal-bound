--!strict

--[[
	DamageRequest

	Shared data model for future damage requests.
	This module builds request tables only. It does not validate, calculate,
	or apply damage.
]]

export type DamageRequest = {
	Attacker: any,
	Target: any,
	Damage: number,
	DamageType: string,
	CrystalId: string?,
	Timestamp: number,
}

local DamageRequest = {}

function DamageRequest.new(attacker: any, target: any, damage: number, damageType: string, crystalId: string?): DamageRequest
	return {
		Attacker = attacker,
		Target = target,
		Damage = damage,
		DamageType = damageType,
		CrystalId = crystalId,
		Timestamp = os.clock(),
	}
end

return DamageRequest

