--!strict

--[[
	CrystalSystem

	Facade for Crystal Framework v1.
	Ownership and equipment changes are handled only by server-side CrystalService.
]]

local CrystalFolder = script.Parent:WaitForChild("Crystal")

local CrystalDefinitions = require(CrystalFolder:WaitForChild("CrystalDefinitions"))
local CrystalTypes = require(CrystalFolder:WaitForChild("CrystalTypes"))
local CrystalUtils = require(CrystalFolder:WaitForChild("CrystalUtils"))
local Abilities = CrystalFolder:WaitForChild("Abilities")
local BaseCrystal = require(Abilities:WaitForChild("BaseCrystal"))
local AbilityRegistry = require(Abilities:WaitForChild("AbilityRegistry"))
local PassiveRegistry = require(Abilities:WaitForChild("PassiveRegistry"))

local CrystalSystem = {
	Definitions = CrystalDefinitions,
	Types = CrystalTypes,
	Utils = CrystalUtils,
	BaseCrystal = BaseCrystal,
	AbilityRegistry = AbilityRegistry,
	PassiveRegistry = PassiveRegistry,
}

function CrystalSystem.Exists(id: string): boolean
	return CrystalUtils.Exists(id)
end

function CrystalSystem.GetDefinition(id: string)
	return CrystalUtils.GetDefinition(id)
end

function CrystalSystem.IsValid(id: string): boolean
	return CrystalUtils.IsValid(id)
end

return CrystalSystem
