--!strict

--[[
	NPCService

	Server-side owner for NPC spawning and orchestration.
	Later this service should create NPCs, track state, and coordinate
	server-controlled NPC behavior.
]]

local NPCService = {}

function NPCService.Init()
	-- Prepare NPC folders, definitions, and spawn dependencies here later.
end

function NPCService.Start()
	-- Start NPC orchestration hooks here later.
end

return NPCService

