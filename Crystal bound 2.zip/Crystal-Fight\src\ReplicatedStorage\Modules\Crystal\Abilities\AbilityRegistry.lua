--!strict

--[[
	AbilityRegistry

	Registry for mapping crystal IDs to ability classes.
	This module contains no gameplay logic. It only resolves which class should
	be instantiated for a crystal.
]]

local BaseCrystal = require(script.Parent:WaitForChild("BaseCrystal"))

local AbilityRegistry = {}

local registeredAbilities: { [string]: any } = {
	-- Future shape:
	-- EMBER = EmberCrystalAbility,
}

function AbilityRegistry.Register(crystalId: string, abilityClass: any): boolean
	if type(crystalId) ~= "string" or crystalId == "" then
		return false
	end

	if type(abilityClass) ~= "table" or type(abilityClass.new) ~= "function" then
		return false
	end

	registeredAbilities[crystalId] = abilityClass
	return true
end

function AbilityRegistry.GetAbilityClass(crystalId: string)
	return registeredAbilities[crystalId] or BaseCrystal
end

function AbilityRegistry.CreateAbility(crystalId: string)
	local abilityClass = AbilityRegistry.GetAbilityClass(crystalId)
	return abilityClass.new(crystalId)
end

function AbilityRegistry.GetRegisteredAbilities()
	local copy = {}
	for crystalId, abilityClass in registeredAbilities do
		copy[crystalId] = abilityClass
	end

	return copy
end

return AbilityRegistry
