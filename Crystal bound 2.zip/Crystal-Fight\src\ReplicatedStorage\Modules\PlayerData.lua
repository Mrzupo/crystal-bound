--!strict

--[[
	PlayerData

	Central place for the shape of a player's profile.
	This module should only describe data defaults and validation helpers.
	Loading and saving should stay inside SaveSystem.
]]

local EconomyConfig = require(script.Parent.Parent:WaitForChild("Config"):WaitForChild("EconomyConfig"))

export type Profile = {
	Level: number,
	Experience: number,
	Crystals: {
		Owned: { string },
		Equipped: string,
	},
	Money: number,
	Stats: {
		Health: number,
		Damage: number,
		Defense: number,
		Speed: number,
	},
	Inventory: { [string]: number },
	ActiveQuests: { string },
	CompletedQuests: { string },
	UnlockedIslands: { string },
	Titles: { string },
}

local PlayerData = {}

local function isArray(value: any): boolean
	if type(value) ~= "table" then
		return false
	end

	for key in value do
		if type(key) ~= "number" then
			return false
		end
	end

	return true
end

local function normalizeCrystalData(crystals: any): { Owned: { string }, Equipped: string }
	local owned = {}
	local seen = {}
	local equipped = ""

	if type(crystals) == "table" then
		if type(crystals.Owned) == "table" then
			for _, crystalId in crystals.Owned do
				if type(crystalId) == "string" and crystalId ~= "" and not seen[crystalId] then
					table.insert(owned, crystalId)
					seen[crystalId] = true
				end
			end
		end

		if type(crystals.Equipped) == "string" then
			equipped = crystals.Equipped
		end
	end

	if equipped ~= "" and not seen[equipped] then
		equipped = ""
	end

	return {
		Owned = owned,
		Equipped = equipped,
	}
end

local function isInventory(value: any): boolean
	if type(value) ~= "table" then
		return false
	end

	for itemId, amount in value do
		if type(itemId) ~= "string" then
			return false
		end

		if type(amount) ~= "number" or amount < 0 or amount ~= math.floor(amount) then
			return false
		end
	end

	return true
end

function PlayerData.NormalizeInventory(inventory: any): { [string]: number }
	local normalized = {}

	if type(inventory) ~= "table" then
		return normalized
	end

	for key, value in inventory do
		if type(key) == "string" and type(value) == "number" and value > 0 then
			normalized[key] = math.floor(value)
		elseif type(key) == "number" and type(value) == "string" then
			-- Migration support for the earlier array-based inventory placeholder.
			normalized[value] = (normalized[value] or 0) + 1
		end
	end

	return normalized
end

function PlayerData.GetDefaultProfile(): Profile
	-- Keep this table small and explicit. Add new fields here before using them elsewhere.
	return {
		Level = 1,
		Experience = 0,
		Crystals = {
			Owned = {},
			Equipped = "",
		},
		Money = EconomyConfig.StartingMoney,
		Stats = {
			Health = 100,
			Damage = 10,
			Defense = 0,
			Speed = 16,
		},
		Inventory = {},
		ActiveQuests = {},
		CompletedQuests = {},
		UnlockedIslands = {},
		Titles = {},
	}
end

function PlayerData.ValidateProfile(profile: any): boolean
	-- Validate the current persisted schema before accepting data from a DataStore.
	if type(profile) ~= "table" then
		return false
	end

	if type(profile.Level) ~= "number" then
		return false
	end

	if type(profile.Experience) ~= "number" then
		return false
	end

	profile.Crystals = normalizeCrystalData(profile.Crystals)
	profile.EquippedCrystal = nil

	if type(profile.Crystals) ~= "table" then
		return false
	end

	if not isArray(profile.Crystals.Owned) then
		return false
	end

	for _, crystalId in profile.Crystals.Owned do
		if type(crystalId) ~= "string" or crystalId == "" then
			return false
		end
	end

	if type(profile.Crystals.Equipped) ~= "string" then
		return false
	end

	if type(profile.Money) ~= "number" then
		return false
	end

	if profile.Money < EconomyConfig.MinMoney then
		return false
	end

	if type(profile.Stats) ~= "table" then
		return false
	end

	if type(profile.Stats.Health) ~= "number" then
		return false
	end

	if type(profile.Stats.Damage) ~= "number" then
		return false
	end

	if type(profile.Stats.Defense) ~= "number" then
		return false
	end

	if type(profile.Stats.Speed) ~= "number" then
		return false
	end

	profile.Inventory = PlayerData.NormalizeInventory(profile.Inventory)

	return isInventory(profile.Inventory)
		and isArray(profile.ActiveQuests)
		and isArray(profile.CompletedQuests)
		and isArray(profile.UnlockedIslands)
		and isArray(profile.Titles)
end

return PlayerData
